# Exercice -3

## Extension Carrousel pour Wordpress

### Contien 5 commits

> L'extension Carrousel contient 6 fichiers:

1. style.scss
2. carrousel.js
3. carrousel.php
4. style.css
5. style.css.map
6. readme.md
